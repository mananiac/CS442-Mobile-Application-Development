package com.example.android_notes;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

import java.util.Date;

public class ActivityEdit extends AppCompatActivity {

    EditText heading,content;
    private NotesClass notesClass;
    private int position;
    private int templocalvariable;
    @Override
    public void onBackPressed() {
        if(templocalvariable != 0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setPositiveButton("OK"        , (dialog, which) -> {
                dialog.dismiss();
                savedataDialog();
            });

            builder.setNegativeButton("CANCEL"        , (dialog, which) -> {
                dialog.dismiss();
                ActivityEdit.super.onBackPressed();
            });

            builder.setTitle("Save note \n '" + heading.getText().toString() + "'?");
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        else{
            ActivityEdit.super.onBackPressed();
        }
    }
    public void getPreviousData(){
        Intent intent = getIntent();
        if (intent.hasExtra("ANDROIDNOTES")) {
            notesClass = (NotesClass) intent.getSerializableExtra("ANDROIDNOTES");
            position = intent.getIntExtra("position",-1);
            if (notesClass != null)
                heading.setText(notesClass.getStrtitle());
            assert notesClass != null;
            content.setText(notesClass.getStrcontent());
        } else {
            heading.setText("");
            content.setText("");
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        heading = findViewById(R.id.heading);
        content = findViewById(R.id.content);
        notesClass = new NotesClass();
        position = -1;
        templocalvariable = 0;

        heading.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                templocalvariable++;
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        content.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                templocalvariable++;
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        getPreviousData();
    }








    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.editactivity_menu, menu);
        return true;
    }
    public void returndatatoactivity(){
        notesClass.setStrcontent(content.getText().toString());
        notesClass.setStrtitle(heading.getText().toString());
        notesClass.setSavetimelast(""+new Date());
        Intent intent = new Intent();
        intent.putExtra("ANDROIDNOTES", notesClass);
        intent.putExtra("position",position);
        setResult(RESULT_OK, intent);
        finish();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.save) {

            if(TextUtils.isEmpty(heading.getText().toString())){
                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                builder.setPositiveButton("OK"           , (dialog, which) -> {
                    dialog.dismiss();
                    onBackPressed();
                });

                builder.setNegativeButton("CANCEL"        , (dialog, which) -> dialog.dismiss());

                builder.setTitle("Saving without a title is not allowed!\n Exit ??");
                AlertDialog dialog = builder.create();
                dialog.show();
                return true;
            }

            returndatatoactivity();

            return true;
        }  else {
            return super.onOptionsItemSelected(item);
        }
    }

    public void savedataDialog(){
        if(TextUtils.isEmpty(heading.getText().toString())){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setPositiveButton("OK"        , (dialog, which) -> {
                dialog.dismiss();
                ActivityEdit.super.onBackPressed();
            });

            builder.setNegativeButton("CANCEL"        , (dialog, which) -> dialog.dismiss());

            builder.setTitle("Saving without a title is not allowed!\n Exit ??");
            AlertDialog dialog = builder.create();
            dialog.show();
            return;
        }

        returndatatoactivity();
    }



}