package com.example.newsaggregator;

public class News_Source {
    private String identification;
    private String name;
    private String type;
    private String link;

    public News_Source(String identiti, String naame, String type, String source){
        setIdentification(identiti);
        setName(naame);
        setType(type);
        setLink(source);
    }

    @Override
    public String toString() { return name; }
    public String getType() { return type; }
    public void setLink(String link) { this.link = link; }
    public String getIdentification() { return identification; }
    public void setName(String name) { this.name = name; }
    public void setIdentification(String identification) { this.identification = identification; }
    public String getName() { return name; }
    public void setType(String type) { this.type = type; }
}
