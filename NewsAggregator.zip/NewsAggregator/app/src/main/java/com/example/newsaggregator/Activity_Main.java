package com.example.newsaggregator;
import android.view.Menu;
import android.view.inputmethod.InputMethodManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import java.util.ArrayList;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import android.app.Activity;
import android.content.res.Configuration;
import android.widget.Toast;
import java.util.LinkedHashSet;
import android.os.Bundle;
import android.view.MenuItem;
import android.text.SpannableString;
import android.graphics.Color;
import java.util.Set;
import android.annotation.SuppressLint;
import androidx.viewpager2.widget.ViewPager2;
import android.text.style.ForegroundColorSpan;
import android.view.View;


public class Activity_Main extends AppCompatActivity {

    private ViewPager2 view_Pager;
    private String [] string_of_colors = {"#ad152e", "#d68c45", "#f4d35e", "#60785c", "#77a0a9", "#6c596e", "#ff8c9f"};
    private ListView main_list_of_drawer;
    static final ArrayList<News_Source> total_items = new ArrayList<>();
    private Adapter_Article adapter_field;
    private  ArrayList<Details_Article> list_of_articles = new ArrayList<>();
    private Menu options;
    static final ArrayList<String> categories = new ArrayList<>();
    String selected_title;
    private DrawerLayout main_layout_of_drawer;
    private ActionBarDrawerToggle main_toggle_of_drawer;
    static final ArrayList<News_Source> selected_items = new ArrayList<>();

    public void loadDrawer(boolean all){
        if(all){
            selected_items.addAll(total_items);
        }
        main_list_of_drawer.setAdapter(new ArrayAdapter<>(this,
                R.layout.drawer_layout_item, selected_items));
        main_layout_of_drawer.setScrimColor(Color.WHITE);
    }
    @SuppressLint("NotifyDataSetChanged")
    private void selectItem(int position) {
        view_Pager.setBackground(null);
        selected_title = selected_items.get(position).getName();
        News_Article_Query news2 = new News_Article_Query(this, selected_items.get(position).getIdentification());
        new Thread(news2).start();

        main_layout_of_drawer.closeDrawer(main_list_of_drawer);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (main_toggle_of_drawer.onOptionsItemSelected(item)) {
            return true;
        }

        for (int i = 0; i < options.size(); i++){
            if(options.getItem(i).getTitle().equals(item.getTitle())){
                reloadSources(categories.get(i));
                break;
            }
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        main_toggle_of_drawer.syncState();
    }
    public void ErrorDownload() {
        Toast.makeText(Activity_Main.this, R.string.error, Toast.LENGTH_SHORT).show();
    }
    public static void addTopic(String t){
        categories.add(t);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.options = menu;
        News_Source_Query.NewsDownloaderTopics(this);

        return super.onCreateOptionsMenu(menu);
    }
    public void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (imm == null) return;

        View view = getCurrentFocus();

        if (view == null)
            view = new View(this);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
    public void addArticle(ArrayList<Details_Article> w) {
        list_of_articles.clear();
        list_of_articles.addAll(w);
        adapter_field.notifyDataSetChanged();
        setTitle(selected_title);
        view_Pager.setCurrentItem(0);
    }
    public void updateData(Object o) {//empty////
        //
        //
    }
    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        main_toggle_of_drawer.onConfigurationChanged(newConfig);
    }
    private void reloadSources(String s) {
        selected_items.clear();
        if(s.equals("All")){
            selected_items.addAll(total_items);
        }
        else{
            for(int i = 0; i < total_items.size(); i++){
                if(total_items.get(i).getType().equals(s)){
                    selected_items.add(total_items.get(i));
                }
            }
        }
        changeTitle(selected_items.size());
        loadDrawer(false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        main_layout_of_drawer = findViewById(R.id.main_layout_drawer);
        main_list_of_drawer = findViewById(R.id.items_of_the_drawer);

        main_list_of_drawer.setAdapter(new ArrayAdapter<>(this,
                R.layout.drawer_layout_item, total_items));

        main_list_of_drawer.setOnItemClickListener(
                (parent, view, position, id) -> {
                    selectItem(position);
                    main_layout_of_drawer.closeDrawer(main_list_of_drawer);
                }
        );

        main_toggle_of_drawer = new ActionBarDrawerToggle(
                this,
                main_layout_of_drawer,
                R.string.drawer_open,
                R.string.drawer_close
        );

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }


        adapter_field = new Adapter_Article(this, list_of_articles);
        view_Pager = findViewById(R.id.pager_widget);
        view_Pager.setAdapter(adapter_field);

    }
    public void changeTitle(int num){
        String temp = new StringBuilder()
                .append(getString(R.string.app_name))
                .append(" (").append(num)
                .append(")").toString();
        setTitle(temp);
    }

    public void makeMenu() {
        options.clear();
        categories.size();

        Set<String> set = new LinkedHashSet<String>();

        set.addAll(categories);
        categories.clear();
        categories.addAll(set);
        for(int i = 0; i < categories.size(); i++){
            options.add( categories.get(i) );
            if(i > 0){
                int newind = i-1;
                MenuItem item = options.getItem(i);
                SpannableString spanString = new SpannableString(item.getTitle().toString());
                spanString.setSpan(new ForegroundColorSpan(Color.parseColor(string_of_colors[newind])), 0, spanString.length(), 0);
                item.setTitle(spanString);
            }
        }
        hideKeyboard();
    }

}