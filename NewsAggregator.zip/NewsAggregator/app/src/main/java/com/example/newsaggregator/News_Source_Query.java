package com.example.newsaggregator;

import org.json.JSONArray;
import com.android.volley.AuthFailureError;
import org.json.JSONObject;
import java.util.Map;
import java.util.HashMap;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.Response;
import com.android.volley.Request;
import com.android.volley.toolbox.Volley;

public class News_Source_Query {
    private static RequestQueue que;
    public static Activity_Main MActiVar;
    private static final String initial_string = "https://newsapi.org/v2/sources?apiKey=";
    private static String link_needed;
    private static final String my_API = "b6d9d19023bd426abc3abc7587299ce0";

    public static void NewsDownloaderTopics(Activity_Main actiVar){
        MActiVar = actiVar;
        que = Volley.newRequestQueue(MActiVar);

        link_needed = initial_string + my_API;

        Response.Listener<JSONObject> listener =
                response -> parseTopics(response.toString());

        Response.ErrorListener error =
                error1 -> MActiVar.ErrorDownload();

        JsonObjectRequest jsonObjectRequest =
                new JsonObjectRequest(Request.Method.GET, link_needed,
                        null, listener, error) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> headers = new HashMap<>();
                        headers.put("User-Agent", "val");
                        return headers;
                    }
                };

        que.add(jsonObjectRequest);
    }

    private static void parseTopics(String s) {
        try {
            Activity_Main.categories.clear();
            Activity_Main.categories.add("All");
            JSONObject jMain = new JSONObject(s);
            JSONArray sources = jMain.getJSONArray("sources");
            for(int i = 0; i < sources.length(); i++) {
                JSONObject specificSource = sources.getJSONObject(i);
                String id = specificSource.getString("id");
                String name = specificSource.getString("name");
                String topic = specificSource.getString("category");
                String url = specificSource.getString("url");

                Activity_Main.total_items.add(new News_Source(id, name, topic, url));

                Activity_Main.addTopic(topic);
            }
            MActiVar.loadDrawer(true);
            MActiVar.makeMenu();
            MActiVar.changeTitle(sources.length());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
