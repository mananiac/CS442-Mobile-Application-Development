package com.example.newsaggregator;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.time.Instant;
import android.annotation.SuppressLint;
import java.time.ZoneId;

public class Details_Article {
    private String link_to_the_image;
    private String matter;
    private String link_of_the_news;
    private String writer_of_the_news;
    private String name_of_the_news;
    private String title_of_the_news;
    private String description_of_the_news;
    private String date_of_the_news;

    public String getLink_to_the_image() {
        return link_to_the_image;
    }
    public void setDescription_of_the_news(String description_of_the_news) {
        if(writer_of_the_news.equals("null")){
            this.description_of_the_news = "No description available";
        }
        else{
            this.description_of_the_news = description_of_the_news;
        }
    }
    public String getTitle_of_the_news() {
        return title_of_the_news;
    }
    public void setLink_of_the_news(String link_of_the_news) {
        this.link_of_the_news = link_of_the_news;
    }
    public String getWriter_of_the_news() {
        return writer_of_the_news;
    }

    public String getDate_of_the_news() {
        return date_of_the_news;
    }
    @Override
    public String toString() {
        return "Article{" +
                "author='" + writer_of_the_news + '\'' +
                ", title='" + title_of_the_news + '\'' +
                ", desc='" + description_of_the_news + '\'' +
                ", url='" + link_of_the_news + '\'' +
                ", urlToImage='" + link_to_the_image + '\'' +
                ", date='" + date_of_the_news + '\'' +
                ", content='" + matter + '\'' +
                '}';
    }
    public void setWriter_of_the_news(String writer_of_the_news) {
        if(writer_of_the_news.equals("null")){
            this.writer_of_the_news = name_of_the_news;
        }
        else{
            this.writer_of_the_news = writer_of_the_news;
        }

    }
    public void setDate_of_the_news(String date_of_the_news) {
        this.date_of_the_news = date_of_the_news;
    }
    public void setMatter(String matter) {
        if(matter.equals("null")){
            this.matter = "";
        }
        else {
            this.matter = matter;
        }
    }

    public void setLink_to_the_image(String link_to_the_image) {
        this.link_to_the_image = link_to_the_image;
    }
    public void setTitle_of_the_news(String title_of_the_news) {
        this.title_of_the_news = title_of_the_news;
    }

    public String getLink_of_the_news() {
        return link_of_the_news;
    }


    @SuppressLint("NewApi")
    public String dateTimeZulu() {
        try {
            DateTimeFormatter parser = DateTimeFormatter.ISO_DATE_TIME;
            Instant instant = parser.parse(this.getDate_of_the_news(), Instant::from);
            LocalDateTime ldt = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM d, yyyy HH:mm ");

            return ldt.format(dtf);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    public String getDescription_of_the_news() {
        return description_of_the_news;
    }
    public Details_Article(String writer, String title, String description, String link, String link_image, String date_news, String c, String newsName){
        this.name_of_the_news = newsName;
        setWriter_of_the_news(writer);
        setDate_of_the_news(date_news);
        setLink_of_the_news(link);
        setDescription_of_the_news(description);
        setLink_to_the_image(link_image);
        setMatter(c);
        setTitle_of_the_news(title);
    }
}
