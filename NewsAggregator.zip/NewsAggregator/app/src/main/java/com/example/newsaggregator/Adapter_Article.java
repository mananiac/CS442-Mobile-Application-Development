package com.example.newsaggregator;
import java.util.ArrayList;
import com.squareup.picasso.Picasso;
import android.view.View;
import android.text.method.ScrollingMovementMethod;
import androidx.annotation.NonNull;
import android.view.ViewGroup;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import androidx.recyclerview.widget.RecyclerView;

public class Adapter_Article extends RecyclerView.Adapter<View_Holder_Article>{
    private final ArrayList<Details_Article> list_of_articles;
    private final Activity_Main main_acti_object;
    @Override
    public void onBindViewHolder(@NonNull View_Holder_Article container, int place) {
        Details_Article spot = list_of_articles.get(place);
        container.headline_of_the_news.setText(spot.getTitle_of_the_news());
        container.date_of_the_news.setText(spot.dateTimeZulu());
        container.writer_of_the_news.setText(spot.getWriter_of_the_news());
        container.picture_of_the_news.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        Picasso.get().load(spot.getLink_to_the_image()).placeholder(R.drawable.noimage).error(R.drawable.brokenimage).into(container.picture_of_the_news);
        container.picture_of_the_news.setOnClickListener(var -> imageClick(spot.getLink_of_the_news()));
        container.matter.setMovementMethod(new ScrollingMovementMethod());
        container.matter.setText(spot.getDescription_of_the_news());
        container.headline_of_the_news.setOnClickListener(var -> imageClick(spot.getLink_of_the_news()));
        container.matter.setOnClickListener(var -> imageClick(spot.getLink_of_the_news()));
        int indicator = place + 1;
        String slide = new StringBuilder().append(indicator).append(" out of ").append(getItemCount()).toString();
        container.number_of_the_page.setText(slide);
    }

    private void imageClick(String url){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        main_acti_object.startActivity(browserIntent);
    }



    @NonNull
    @Override
    public View_Holder_Article onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new View_Holder_Article(
                LayoutInflater.from(parent.getContext()).
                        inflate(R.layout.article_layout, parent, false));
    }

    @Override
    public int getItemCount() {
        return list_of_articles.size();
    }

    public Adapter_Article(Activity_Main acti_main, ArrayList<Details_Article> articles){
        this.main_acti_object = acti_main;
        this.list_of_articles = articles;
    }

}
