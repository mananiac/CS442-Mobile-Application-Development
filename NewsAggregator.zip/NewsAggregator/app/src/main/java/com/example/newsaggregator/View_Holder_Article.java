package com.example.newsaggregator;

import android.view.View;
import androidx.annotation.NonNull;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class View_Holder_Article extends RecyclerView.ViewHolder{
    ImageView picture_of_the_news;
    TextView number_of_the_page;
    TextView date_of_the_news;
    TextView matter;
    TextView writer_of_the_news;
    TextView headline_of_the_news;

    public View_Holder_Article(@NonNull View itemView){
        super(itemView);
        headline_of_the_news = itemView.findViewById(R.id.headline_of_the_news);
        writer_of_the_news = itemView.findViewById(R.id.writer);
        picture_of_the_news = itemView.findViewById(R.id.picture);
        number_of_the_page = itemView.findViewById(R.id.page_no);
        matter = itemView.findViewById(R.id.desc_of_the_news);
        date_of_the_news = itemView.findViewById(R.id.date_of_the_news);
    }
}
