package com.example.newsaggregator;
import java.io.BufferedReader;
import java.util.ArrayList;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.InputStreamReader;
import javax.net.ssl.HttpsURLConnection;
import java.io.InputStream;
import java.net.URL;

public class News_Article_Query implements Runnable {

    public static Activity_Main acti_main;
    private static final String initial_string = "https://newsapi.org/v2/top-headlines?sources=" ;
    private static final String my_API = "&apiKey=b6d9d19023bd426abc3abc7587299ce0";
    private static String name_of_news_source;

    News_Article_Query(Activity_Main main, String newsSource) {
        this.acti_main = main;
        this.name_of_news_source = newsSource;
    }
    public void handleResults(final String jsonString) {
        final ArrayList<Details_Article> w = parseArticlesJSON(jsonString);
        acti_main.runOnUiThread(() -> acti_main.addArticle(w));
    }
    @Override
    public void run(){

        String final_url = initial_string + name_of_news_source + my_API;
        StringBuilder string_builder_object = new StringBuilder();
        try {
            URL url = new URL(final_url);

            HttpsURLConnection conn_object = (HttpsURLConnection) url.openConnection();
            conn_object.setRequestMethod("GET");
            conn_object.addRequestProperty("User-Agent","");
            conn_object.connect();

            if (conn_object.getResponseCode() != HttpsURLConnection.HTTP_OK) {
                handleResults(null);
                return;
            }

            InputStream input_stream_object = conn_object.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(input_stream_object)));

            String position;
            while ((position = reader.readLine()) != null) {
                string_builder_object.append(position).append('\n');
            }

        } catch (Exception e) {
            handleResults(null);
            return;
        }
        handleResults(string_builder_object.toString());
    }




    private ArrayList<Details_Article> parseArticlesJSON(String s) {
        try {
            JSONObject json_object_variable = new JSONObject(s);
            JSONArray array_of_news = json_object_variable.getJSONArray("articles");
            ArrayList<Details_Article> articles = new ArrayList<>();

            for (int i = 0; i < array_of_news.length(); i++) {
                JSONObject specific_article = (JSONObject) array_of_news.get(i);
                JSONObject source = (JSONObject) specific_article.getJSONObject("source");
                String urlToImage = specific_article.getString("urlToImage");
                String description = specific_article.getString("description");
                String newsName = source.getString("name");
                String url = specific_article.getString("url");
                String publishedAt = specific_article.getString("publishedAt");
                String author = specific_article.getString("author");
                String title = specific_article.getString("title");
                String content = specific_article.getString("content");

                Details_Article article = new Details_Article(author,title,description,url,urlToImage,publishedAt,content, newsName);
                articles.add(article);
            }

            return articles;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
